# 🔭 UAE Science Quests

A single-page quiz game about science in the UAE: **Old Times → Now → Future**.
Answer quests, earn points, unlock book recommendations, collect badges and a final certificate.

## Features
- 3 eras × 6 quests (18 total), each with a longer story, a free hint and a "Did you know?" fact
- 5 task types: Choose, True or False, Put in Order, Match, Number Puzzle
- Book to read after every quest
- Points (mistakes lower the score, minimum 20), 5 ranks, era badges and a printable certificate
- Progress saved in the browser (localStorage)
- Light and dark mode, works on phones

## Run locally
Just open `index.html` in a browser. No build step or dependencies.

## Publish free with GitHub Pages
1. Create a new repository on GitHub and upload these files.
2. Go to **Settings → Pages**.
3. Under **Branch**, choose `main` and `/ (root)`, then Save.
4. Your site will appear at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Add your own quests
Open `index.html` and find the `Q` array. Every quest has the same base fields:

```js
{e:"future",            // era: "past", "now" or "future"
 type:"choice",         // see the task types below
 t:"Title",
 s:"Story paragraph 1\n\nStory paragraph 2",
 q:"Question or instruction",
 h:"Hint text",
 f:"Fun fact shown after solving",
 bk:["Book title","Author","Why to read it"]}
```

Then add the fields for its task type:

| type | extra fields | example |
|---|---|---|
| `choice` | `o` options, `a` index of correct option | `o:["A","B","C"], a:1` |
| `tf` | `st` list of [sentence, true/false] | `st:[["Mars is red.",true]]` |
| `order` | `items` in the **correct** order (shuffled on screen) | `items:["First","Second","Third"]` |
| `match` | `pairs` of [left, right] (right side shuffled) | `pairs:[["Kamal","Finds latitude"]]` |
| `num` | `ans` number, `unit` label | `ans:6, unit:"years"` |

Any number of quests per era works; counters and badges update automatically.

## Note
Please verify facts and book details before using this in a classroom.

## License
MIT
