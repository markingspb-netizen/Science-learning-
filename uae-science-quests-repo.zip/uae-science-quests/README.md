# 🔭 UAE Science Quests

A single-page quiz game about science in the UAE: **Old Times → Now → Future**.
Answer quests, earn points, unlock book recommendations, collect badges and a final certificate.

## Features
- 3 eras × 3 quests (9 total)
- Book to read after every quest
- Points, ranks, era badges and a certificate
- Progress saved in the browser (localStorage)
- Light and dark mode, works on phones

## Run locally
Just open `index.html` in a browser. No build step or dependencies.

## Publish free with GitHub Pages
1. Create a new repository on GitHub and upload these files.
2. Go to **Settings → Pages**.
3. Under **Branch**, choose `main` and `/ (root)`, then Save.
4. Your site will appear at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Add your own quests
Open `index.html` and find the `Q` array. Add an object like this:

```js
{e:"future", t:"Title", s:"Story text", q:"Question?",
 o:["Option A","Option B","Option C"], a:1,   // a = index of the correct option
 f:"Fun fact shown after answering",
 bk:["Book title","Author","Why to read it"]}
```

Keep 3 quests per era (`past`, `now`, `future`) or update the "/3" counters.

## Note
Please verify facts and book details before using this in a classroom.

## License
MIT
