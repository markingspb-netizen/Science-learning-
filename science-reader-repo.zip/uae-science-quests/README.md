# Science Reader

A free science reading website: **128 true science stories, each with 3 comprehension questions**,
plus accounts, an avatar shop and a community area where readers make their own tasks (checked by AI before publishing).

## What's inside
- **Library:** 128 articles in 13 topics, including *UAE science* and *Science around the world*.
  Read, then answer, then results. Every answer is in the text, and after checking, the paragraph with the answer is highlighted.
- **Accounts:** log in, create an account, or continue as a guest.
  Guests can read and earn points, but their progress stays on that device and they can't publish community tasks.
- **Avatar shop:** earn points in the library (10 per correct answer on the first try, +20 for 3 out of 3),
  then spend them on backgrounds, hair, glasses, headwear, outfits and badges. Free items are always available.
- **Community tasks:** a separate area. Readers with an account can write a short science text with 1–3 questions.
  Other people's tasks stay hidden until you press **See tasks by others**. Community tasks **don't give points**.
  Authors can delete their own tasks; anyone can report a task, and tasks with 3 reports are hidden.
- Real photos from Wikipedia (free-licence images only), with the author and licence shown. Listen button, larger text, works on phones.

## Step 1: put the photos on your own site (one click)
Photos are downloaded from Wikimedia into the `photos` folder of your repository, so they load fast and nothing can block them.
1. Upload the whole project to GitHub, including the hidden `.github` folder and the `tools` and `photos` folders.
   *Tip: on github.com you can't upload a folder that starts with a dot by drag-and-drop on some devices. If `.github` is missing, click
   **Add file → Create new file**, type `.github/workflows/photos.yml` as the name, and paste the contents of that file.*
2. On GitHub, open the **Actions** tab. If asked, click **I understand my workflows, go ahead and enable them**.
3. Click **Download photos** on the left, then **Run workflow → Run workflow**.
4. Wait 2–3 minutes until it shows a green tick. The photos and `photos/credits.json` (author and licence of each photo) are now in your repository, and Render updates the site by itself.
Run it again whenever you add new articles. If the `photos` folder is empty, the site tries to load photos straight from Wikipedia instead.

## Step 2 (optional): a stronger AI check with Claude
Before a community task is published it is always checked:
- **Basic rules** (always): no links, emails, phone numbers, ALL CAPS or spam.
- **AI safety check in the browser** (free, no setup): a small AI model (TensorFlow.js "toxicity") looks for rude, unkind or adult language.
  If it can't load, only the basic rules are used.
- **Claude checker** (optional, best): Claude also checks that the task is about science, that the facts are right and that the answers are in the text.
  It runs on a tiny server so your API key stays secret. Each check costs a tiny fraction of a cent.

To set up the Claude checker:
1. Get an API key at **console.anthropic.com** (an adult needs to add a small amount of credit).
2. On **render.com**: **New → Web Service**, connect the same GitHub repository.
   - **Root Directory:** `checker`
   - **Build Command:** `npm install`  **Start Command:** `node server.js`
   - **Instance type:** Free
   - **Environment variables:** `ANTHROPIC_API_KEY` = your key; `ALLOWED_ORIGIN` = your site address, e.g. `https://science-learning-g4kd.onrender.com`
3. When it's live, copy its address (for example `https://science-checker.onrender.com`).
4. In `index.html`, find `const CHECK_URL="";` and put the address with `/check` at the end:
   `const CHECK_URL="https://science-checker.onrender.com/check";`
Free Render servers fall asleep when nobody uses them, so the first check of the day can take about a minute.

## Two modes

| | Device mode (default) | Online mode (Firebase) |
|---|---|---|
| Setup | none | about 15 minutes, free |
| Accounts | saved on this device only | work on any device |
| Community tasks | only tasks made on this device | everyone sees everyone's tasks |

The site works in device mode straight away. To let classmates see each other's tasks, switch on online mode:

## Turning on online mode (Firebase, free)
1. Go to **console.firebase.google.com** and sign in with a Google account (a parent or teacher should do this).
2. Click **Create a project**, give it a name, and finish the steps (Google Analytics can be turned off).
3. In the left menu open **Build → Authentication → Get started**. Under **Sign-in method**, turn on
   **Email/Password** and **Anonymous** (Anonymous is for guests).
4. Open **Build → Firestore Database → Create database**. Choose a location near you and start in **production mode**.
5. In Firestore, open the **Rules** tab, delete what is there, paste everything from the file `firestore.rules`, and click **Publish**.
   If you want an admin who can delete any task, change `admin@students.example.com` to `YOURUSERNAME@students.example.com` (lowercase).
6. Go to **Project settings** (gear icon) → **Your apps** → click the **</>** (Web) icon, register the app, and copy the
   `firebaseConfig` object it shows. It looks like this:
   ```js
   { apiKey: "...", authDomain: "...", projectId: "...", storageBucket: "...", messagingSenderId: "...", appId: "..." }
   ```
7. Open `index.html`, find `const FIREBASE_CONFIG=null;` near the start of the script, and replace `null` with that object.
   Also put the admin username in `const ADMINS=[];`, for example `const ADMINS=["mark"];`
8. Upload the new `index.html` to GitHub. Done!

These Firebase keys are meant to be public in a website; the security rules are what protect the data.

**Note:** accounts made in device mode are not moved online. After switching, everyone creates a new account.

## Safety notes for a school
- Usernames are turned into a fake email (`name@students.example.com`) inside Firebase, so no real email is collected. Tell students not to use their real full name.
- Community tasks are checked by rules and AI before publishing, and readers can report tasks. No checker is perfect, so an adult should still look at the community area now and then (an admin can delete any task).
- The checks run in the browser (or ask the checker server), so a tech-savvy student could skip them. Reports and the admin are the safety net.
- Points are counted in the browser, so a tech-savvy student could cheat. That's fine for fun, but don't use the points for grades.

## Add your own library article
In `index.html`, find `A.push(` and add an object:

```js
{id:"x1", tp:"world", e:"", t:"Title", s:"One-sentence summary",
 p:["Paragraph 1","Paragraph 2","Paragraph 3"],
 q:[["Detail","Question?",["CORRECT answer","wrong","wrong","wrong"],1],   // last number = paragraph with the answer (0 = first)
    ["Vocabulary","Question?",["CORRECT","wrong","wrong","wrong"],0],
    ["Cause & effect","Question?",["CORRECT","wrong","wrong","wrong"],2]]}
```
Write the correct answer first; the site mixes up the order. For a photo add `x1:["Wikipedia article title"]` to the `IMG` list.
Topics: uae, space, earth, body, animals, plants, energy, tech, people, ocean, matter, physics, world.

## Publish free with GitHub Pages or Render
Upload `index.html` to your repository. On GitHub Pages: **Settings → Pages → Branch: main, / (root)**. Render static sites update automatically after each commit.

## Note
Facts were written carefully, but please double-check dates and numbers before classroom use.

## License
MIT
