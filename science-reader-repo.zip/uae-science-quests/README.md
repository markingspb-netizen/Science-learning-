# 🔬 Science Reader

A free science reading library in the style of a reading-practice website:
**110 real science stories, each with 3 comprehension questions** (330 questions in total).

## Features
- 110 articles in 12 topics: UAE Science, Space, Earth & Weather, Human Body, Animals, Plants,
  Energy & Environment, Technology, Famous Scientists, Ocean, Chemistry, Physics
- Lesson steps: **1 · Read → 2 · Activity → 3 · Results**
- Every answer can be found in the article; numbered paragraphs, and after submitting,
  each question links to the paragraph with the answer
- Question skills: Detail, Main idea, Vocabulary, Cause & effect, Sequence, Compare, Inference, Figurative language, Author's purpose
- Featured-article carousel, search, topic filters, "Not done yet / Completed" filter
- Listen (browser voice) and larger text
- Real photos: loaded in the visitor's browser from Wikipedia (free-licence images only), with author and licence shown under each article photo. Image choices are in the `IMG` list in `index.html` (Wikipedia article titles; the first one with a free image is used)
- Points (10 per correct answer on the first try, +20 bonus for 3/3), first-try average, progress bar
- Progress saved in the browser (localStorage); light and dark mode; works on phones

## Run locally
Open `index.html` in a browser. No build step or dependencies.

## Publish free with GitHub Pages
1. Upload `index.html` (and this README) to a GitHub repository.
2. Go to **Settings → Pages**, choose branch `main` and `/ (root)`, then Save.
3. Your site appears at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Add your own article
In `index.html`, find `A.push(` and add an object:

```js
{id:"x1", tp:"space", e:"🌟",   // e is no longer shown; add a photo with IMG.x1=["Wikipedia title"]
 t:"Title", s:"One-sentence summary",
 p:["Paragraph 1","Paragraph 2","Paragraph 3"],
 q:[["Detail","Question?",["CORRECT answer","wrong","wrong","wrong"],1],   // last number = paragraph with the answer (0 = first)
    ["Vocabulary","Question?",["CORRECT","wrong","wrong","wrong"],0],
    ["Cause & effect","Question?",["CORRECT","wrong","wrong","wrong"],2]]}
```

Always write the correct answer **first**; the app mixes the order on screen.
`tp` must be one of: uae, space, earth, body, animals, plants, energy, tech, people, ocean, matter, physics.
Use a new `id` for every article.

## Note
Facts were written carefully but please double-check dates and numbers before classroom use.

## License
MIT
