// Science Reader – community task checker.
// Receives a task from the website, asks Claude whether it is kind, safe, about science
// and correct, and answers {ok, problems[], tips[]}. The API key stays secret on the server.
//
// Environment variables (set them on Render):
//   ANTHROPIC_API_KEY  your key from console.anthropic.com   (required)
//   ALLOWED_ORIGIN     your website address, e.g. https://science-learning-g4kd.onrender.com
//   MODEL              optional, default claude-haiku-5-5
import http from "node:http";

const KEY = process.env.ANTHROPIC_API_KEY;
const ORIGIN = process.env.ALLOWED_ORIGIN || "*";
const MODEL = process.env.MODEL || "claude-haiku-5-5";
const API = process.env.ANTHROPIC_BASE || "https://api.anthropic.com";
const PORT = process.env.PORT || 3000;
const LIMIT_PER_HOUR = 30;

const SYSTEM = `You review short science tasks written by students aged about 10 to 14 for a school science reading website in the UAE.
A task has a title, a topic, a short text and 1 to 3 multiple-choice questions (the index "a" marks the correct option, counting from 0).
Decide if it can be published. Reject it (ok:false) if ANY of these is true:
- it contains rude, mean, bullying, hateful, violent, sexual, scary or otherwise unsuitable content for children, or mocks a real person, group, religion or country;
- it contains personal information (full names of real children, addresses, phone numbers, schools, social media handles);
- it is not about science, nature, technology, health or how the world works;
- it is nonsense, spam, or copied gibberish;
- the marked correct answer is wrong, or a question cannot be answered from the text;
- it states something clearly false as a science fact.
Be kind and encouraging: students are learning. Small spelling mistakes are fine.
Reply with ONLY a JSON object, no other text:
{"ok": true or false, "problems": ["short, friendly sentence a child can understand", ...], "tips": ["optional short idea to improve the task", ...]}
Use at most 3 problems and 2 tips. If ok is true, problems must be an empty list.`;

const hits = new Map();
function limited(ip) {
  const now = Date.now(), list = (hits.get(ip) || []).filter(t => now - t < 3600e3);
  list.push(now); hits.set(ip, list);
  return list.length > LIMIT_PER_HOUR;
}
function send(res, code, obj) {
  res.writeHead(code, {
    "content-type": "application/json",
    "access-control-allow-origin": ORIGIN,
    "access-control-allow-methods": "POST, OPTIONS",
    "access-control-allow-headers": "content-type"
  });
  res.end(JSON.stringify(obj));
}
function valid(t) {
  return t && typeof t.title === "string" && typeof t.text === "string" && Array.isArray(t.qs) &&
    t.title.length <= 80 && t.text.length <= 1500 && t.qs.length >= 1 && t.qs.length <= 3 &&
    t.qs.every(q => q && typeof q.q === "string" && Array.isArray(q.o) && q.o.length === 4 && Number.isInteger(q.a) && q.a >= 0 && q.a < 4);
}

http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  if (req.method === "GET") return send(res, 200, { status: "Science Reader checker is running" });
  if (req.method !== "POST") return send(res, 405, { error: "Use POST" });
  if (!KEY) return send(res, 500, { error: "ANTHROPIC_API_KEY is not set" });
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "").split(",")[0].trim();
  if (limited(ip)) return send(res, 429, { error: "Too many checks. Try again later." });

  let body = "";
  for await (const chunk of req) { body += chunk; if (body.length > 20000) return send(res, 413, { error: "Too big" }); }
  let task;
  try { task = JSON.parse(body); } catch { return send(res, 400, { error: "Bad JSON" }); }
  if (!valid(task)) return send(res, 400, { error: "Bad task" });

  const clean = { title: task.title, topic: task.tp, text: task.text, questions: task.qs.map(q => ({ question: q.q, options: q.o, correct_index: q.a })) };
  try {
    const r = await fetch(API + "/v1/messages", {
      method: "POST",
      headers: { "x-api-key": KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: MODEL, max_tokens: 500, system: SYSTEM, messages: [{ role: "user", content: "Task to review:\n" + JSON.stringify(clean) }] })
    });
    if (!r.ok) { console.error("Claude API error", r.status, await r.text()); return send(res, 502, { error: "AI unavailable" }); }
    const data = await r.json();
    const text = (data.content || []).map(c => c.text || "").join("");
    const json = JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1));
    const ok = json.ok === true;
    return send(res, 200, {
      ok,
      problems: ok ? [] : (Array.isArray(json.problems) && json.problems.length ? json.problems.slice(0, 3).map(String) : ["The checker couldn’t approve this task. Try changing it."]),
      tips: Array.isArray(json.tips) ? json.tips.slice(0, 2).map(String) : []
    });
  } catch (e) {
    console.error(e);
    return send(res, 502, { error: "AI unavailable" });
  }
}).listen(PORT, () => console.log("Checker listening on " + PORT));
