// Downloads one free-licence photo per article from Wikipedia/Wikimedia Commons
// into photos/<id>.jpg and writes photos/credits.json (author + licence).
// Run by the GitHub Action "Download photos" (or locally: node tools/fetch-photos.mjs).
import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const API = process.env.WIKI_API || "https://en.wikipedia.org/w/api.php";
const UA = "ScienceReaderPhotoFetcher/1.0 (school project; GitHub Actions)";
const OUT = path.join(ROOT, "photos");
const WIDTH = 800;
const sleep = ms => new Promise(r => setTimeout(r, ms));

// read the IMG list straight out of index.html
const html = fs.readFileSync(path.join(ROOT, "index.html"), "utf8");
const m = html.match(/const IMG=(\{[\s\S]*?\n\});/);
if (!m) throw new Error("Could not find the IMG list in index.html");
const IMG = Function('"use strict";return (' + m[1] + ")")();

async function api(params) {
  const url = API + "?" + new URLSearchParams({ format: "json", formatversion: "2", ...params });
  for (let i = 0; i < 4; i++) {
    const r = await fetch(url, { headers: { "User-Agent": UA } });
    if (r.ok) return r.json();
    await sleep(1500 * (i + 1));
  }
  throw new Error("Wikipedia API failed: " + url.slice(0, 120));
}

const titles = [...new Set(Object.values(IMG).flat())];
const byTitle = {};
for (let i = 0; i < titles.length; i += 50) {
  const chunk = titles.slice(i, i + 50);
  const r = await api({ action: "query", redirects: "1", prop: "pageimages", piprop: "thumbnail|name", pithumbsize: String(WIDTH), pilimit: "50", titles: chunk.join("|") });
  const q = r.query || {}, alias = {};
  (q.normalized || []).forEach(x => (alias[x.to] = (alias[x.to] || []).concat(x.from)));
  (q.redirects || []).forEach(x => (alias[x.to] = (alias[x.to] || []).concat(x.from, ...(alias[x.from] || []))));
  (q.pages || []).forEach(p => {
    if (p.thumbnail && p.pageimage) {
      const v = { thumb: p.thumbnail.source, file: p.pageimage, title: p.title };
      byTitle[p.title] = v;
      (alias[p.title] || []).forEach(t => (byTitle[t] = v));
    }
  });
  await sleep(300);
}

fs.mkdirSync(OUT, { recursive: true });
const credits = {};
const clean = s => String(s || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
let ok = 0, missing = [];
for (const [id, list] of Object.entries(IMG)) {
  const v = list.map(t => byTitle[t]).find(Boolean);
  if (!v) { missing.push(id); continue; }
  try {
    const r = await fetch(v.thumb, { headers: { "User-Agent": UA } });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const type = r.headers.get("content-type") || "";
    const ext = type.includes("png") ? "png" : type.includes("webp") ? "webp" : type.includes("gif") ? "gif" : "jpg";
    const name = `${id}.${ext}`;
    fs.writeFileSync(path.join(OUT, name), Buffer.from(await r.arrayBuffer()));
    const info = await api({ action: "query", prop: "imageinfo", iiprop: "extmetadata", titles: "File:" + v.file });
    const md = (((info.query || {}).pages || [])[0]?.imageinfo || [])[0]?.extmetadata || {};
    credits[id] = {
      file: "photos/" + name,
      title: v.title,
      source_file: v.file,
      author: clean(md.Artist?.value) || "unknown author",
      license: clean(md.LicenseShortName?.value),
      licenseUrl: clean(md.LicenseUrl?.value)
    };
    ok++;
    console.log("✓", id, "←", v.title);
  } catch (e) {
    console.log("✗", id, e.message);
    missing.push(id);
  }
  await sleep(250);
}
fs.writeFileSync(path.join(OUT, "credits.json"), JSON.stringify(credits, null, 1));
console.log(`\nDone: ${ok} photos saved. No free photo for: ${missing.join(", ") || "none"}`);
